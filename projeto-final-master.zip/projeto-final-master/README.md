# Configuracao automática de protocolos

**Descrição:**

A aplicação xpto tem como objetivo a configuração automática dos protocolos de roteamento RIP, EIGRP e OSPF nos dispositivos de rede em sua rede local.

**Ambiente:**

Inicialmente os testes serão realizados em VMs integradas ao VirtualBox, este sendo adequado para simular roteadores entre outros dispositivos de redes.

**Funcionalidades**

  1. Configurar automáticamente a rede com os protocolos disponíveis
  
  2. Monitoramento da rede local

